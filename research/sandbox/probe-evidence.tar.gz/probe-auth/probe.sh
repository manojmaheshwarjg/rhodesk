#!/bin/bash
# probe.sh <case-id> <url> [extra curl args...]
D="/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-auth"
ID="$1"; URL="$2"; shift 2
code=$(curl -s -o "$D/$ID.body" -D "$D/$ID.headers" -w '%{http_code}' --max-time 30 "$URL" "$@")
echo "### CASE=$ID URL=$URL STATUS=$code"
echo "--- headers ---"; cat "$D/$ID.headers"
echo "--- body (first 900 bytes) ---"; head -c 900 "$D/$ID.body"; echo
echo "--- body bytes: $(wc -c < "$D/$ID.body") ---"
echo
