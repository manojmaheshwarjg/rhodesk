HTTP/2 200 
date: Fri, 11 Sep 2026 23:46:04 GMT
content-type: application/json
via: 1.1 google
cf-cache-status: DYNAMIC
referrer-policy: strict-origin-when-cross-origin
strict-transport-security: max-age=63072000; includeSubDomains; preload
x-content-type-options: nosniff
x-frame-options: DENY
server: cloudflare
cf-ray: a39a8cb6fd5743d0-EWR

