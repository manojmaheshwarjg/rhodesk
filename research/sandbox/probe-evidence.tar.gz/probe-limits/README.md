# Evidence index: sandbox transport / rate-limit probe
Target: https://rhoapi-sandbox.rho.co/api/v1  (bearer "sandbox" unless noted)
Captured 2026-09-11, 23:43:17 to 23:53:43 UTC, from a single client IP, all requests landed on Cloudflare colo EWR.

| File | What it is |
| --- | --- |
| 01-baseline.{body,headers,verbose} | Full curl -v of GET /accounts: TLS handshake, ALPN, cert, h2 frames |
| 02-enc-*.{body,headers} | Accept-Encoding negotiation: gzip, br, deflate, zstd, identity, *, none |
| 03-inm-star / 04-inm-fake | If-None-Match conditional requests |
| 05-ims-future / 06-ims-past | If-Modified-Since conditional requests |
| 07-head.headers | HEAD /accounts -> 405 |
| 08-options / 09-preflight / 10-get-origin | OPTIONS, CORS preflight, GET with Origin |
| 11-method-*.{body,headers} | POST PUT PATCH DELETE TRACE FOO |
| 12-404 / 13-root | Unknown /api/v1 path, and host root |
| 14-post-cl0 / 15-post-json | POST with Content-Length |
| 20-latency-coldconn.tsv | Run A: 20 sequential, new TLS connection each, paced 1.1s |
| 21-latency-keepalive.tsv | Run B: 20 sequential over one reused h2 connection |
| 30-burst1-seq60.txt | Run C: 60 sequential, one connection, unpaced |
| 31-burst2-par60.txt + burst2/ | Run D: 60 requests at concurrency 30 |
| 32-burst3-heavy30.txt + burst3/ | Run G: 30 requests at concurrency 30 on 40 KB payload |
| 33-burst4-par60conc60.txt + burst4/ | Run E: 60 requests at concurrency 60 |
| 34-h2-multiplex50.txt | Run F: 50 requests multiplexed on ONE h2 connection |
| 35-burst5-uniqtoken65.txt + 35-burst5-token.txt | Run H: 65 requests on a never-before-seen bearer token |
| 40-http11.headers | Forced HTTP/1.1 |
| 41-tls12.headers / 42-openssl.txt / cert_*.pem | TLS 1.2 negotiation, full cert chain |
| 50-prod-noauth / 51-prod-badtok | Production rhoapi.rho.co 401 comparison |
| 52-sb-emptybearer | Sandbox empty bearer -> 401 |
| 60-longurl / 61-longurl16k / 62-bighdr | URI and header size limits |
| 63-unknownparam | Unknown query param + invalid page_size |
| 64-mcp_* / 65-prod-mcp | /mcp, /mcp/v1, /api/v1/mcp on sandbox and production |
| 70-h2-settings.txt | h2 connection reuse trace |
| 71-http80 / 72-ipv4 / 73-ipv6 | Port 80 redirect, address family |
| 80-*.{body,headers} | Error catalogue: 404 unknown id, 400 bad id, 400 page_size, 400 sort_by |
