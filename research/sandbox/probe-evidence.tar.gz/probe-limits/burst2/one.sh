#!/bin/bash
P="/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-limits"
i="$1"
t0=$(python3 -c 'import time;print(f"{time.time():.3f}")')
out=$(curl -s -o "$P/burst2/b_$i.body" -D "$P/burst2/b_$i.h" -w '%{http_code} %{time_total}' -H "Authorization: Bearer sandbox" https://rhoapi-sandbox.rho.co/api/v1/accounts)
t1=$(python3 -c 'import time;print(f"{time.time():.3f}")')
echo "$i $out $t0 $t1"
