#!/bin/bash
P="/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-limits"
i="$1"
out=$(curl -s -o "$P/burst3/b_$i.body" -D "$P/burst3/b_$i.h" -w '%{http_code} %{time_total} %{size_download}' -H "Authorization: Bearer sandbox" "https://rhoapi-sandbox.rho.co/api/v1/transactions?page_size=100")
echo "$i $out"
