#!/bin/bash
P="/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-limits"
i="$1"
out=$(curl -s -o /dev/null -D "$P/burst4/b_$i.h" -w '%{http_code} %{time_total}' -H "Authorization: Bearer sandbox" https://rhoapi-sandbox.rho.co/api/v1/accounts)
echo "$i $out"
