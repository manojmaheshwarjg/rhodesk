#!/bin/bash
# usage: p.sh <name> <path-with-query>
D="/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-pagination"
NAME="$1"; shift
URL="https://rhoapi-sandbox.rho.co/api/v1$1"
curl -sS -D "$D/$NAME.headers" -o "$D/$NAME.json" -H "Authorization: Bearer sandbox" -G "$URL" 2>"$D/$NAME.err"
echo "--- $NAME  $URL"
head -1 "$D/$NAME.headers"
python3 - "$D/$NAME.json" <<'PY'
import json,sys
try:
    b=json.load(open(sys.argv[1]))
except Exception as e:
    print("NONJSON:", open(sys.argv[1]).read()[:400]); raise SystemExit
if isinstance(b,dict):
    for k,v in b.items():
        if isinstance(v,list):
            print(f"  {k}: len={len(v)}  first_id={v[0].get('id') if v else None}  last_id={v[-1].get('id') if v else None}")
        else:
            print(f"  {k}: {json.dumps(v)[:300]}")
else:
    print(json.dumps(b)[:500])
PY
