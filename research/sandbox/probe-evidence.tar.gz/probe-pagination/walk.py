import json,subprocess,sys,base64,os
D=os.path.dirname(os.path.abspath(__file__))
def get(path,params):
    q="&".join(f"{k}={v}" for k,v in params.items())
    url=f"https://rhoapi-sandbox.rho.co/api/v1{path}?{q}"
    out=subprocess.run(["curl","-sS","-w","\n%{http_code}","-H","Authorization: Bearer sandbox",url],capture_output=True,text=True).stdout
    body,code=out.rsplit("\n",1)
    return int(code),json.loads(body),url
def d(s):
    s=s.replace('-','+').replace('_','/'); s+='='*(-len(s)%4); return base64.b64decode(s).decode()
def walk(path,key,ps,tag):
    tok=None;pages=[];ids=[];log=[]
    while True:
        p={"page_size":ps}
        if tok: p["page_token"]=tok
        code,b,url=get(path,p)
        if code!=200:
            log.append({"url":url,"code":code,"body":b}); break
        items=b[key]; nt=b["page"]["next_page_token"]
        try: dec=json.loads(d(nt)) if nt else None
        except Exception: dec=None
        if dec: dec["t_decoded"]=d(dec["t"])
        log.append({"url":url,"code":code,"n":len(items),"ids":[i.get("id") for i in items],"next":nt,"decoded":dec})
        pages.append(items); ids+= [i.get("id") for i in items]
        if nt is None: break
        tok=nt
        if len(pages)>400: log.append({"ABORT":"too many pages"}); break
    json.dump(log,open(f"{D}/walk_{tag}.json","w"),indent=1)
    dup = len(ids)!=len(set(ids))
    print(f"{path} ps={ps}: pages={len(pages)} total={len(ids)} unique={len(set(ids))} dup={dup} last_page_n={len(pages[-1]) if pages else 0}")
    return ids
if __name__=="__main__":
    specs=[("/accounts","accounts"),("/cards","cards"),("/transactions","transactions"),("/statements","statements"),("/invoicing/customers","customers"),("/invoicing/invoices","invoices")]
    res={}
    for path,key in specs:
        for ps in (1,3,7,100):
            tag=path.strip("/").replace("/","_")+f"_ps{ps}"
            res[(path,ps)]=walk(path,key,ps,tag)
    # ordering stability across page sizes
    print("\n--- ordering identical across page sizes? ---")
    for path,key in specs:
        base=res[(path,1)]
        for ps in (3,7,100):
            same = base==res[(path,ps)]
            print(f"  {path}: ps=1 vs ps={ps} -> {'IDENTICAL' if same else 'DIFFERENT'}")
    json.dump({f"{p}|{ps}":v for (p,ps),v in res.items()},open(f"{D}/walk_all_ids.json","w"),indent=1)
