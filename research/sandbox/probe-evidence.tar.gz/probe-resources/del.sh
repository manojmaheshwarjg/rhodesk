#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
echo "##### customers: default list vs include_deleted=true"
curl -sS -H "Authorization: Bearer sandbox" "$B/invoicing/customers" > "$D/cust_default.json"
curl -sS -H "Authorization: Bearer sandbox" "$B/invoicing/customers?include_deleted=true" > "$D/cust_incl.json"
python3 - <<'PY'
import json
a=json.load(open('/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-resources/cust_default.json'))['customers']
b=json.load(open('/private/tmp/claude-501/-Users-manojmaheshwarjagadeesan-Desktop-Vivpro-Codebase-regain-frontend/32689851-de1d-4894-8a66-652780dfadbf/scratchpad/rho/sandbox/probe-resources/cust_incl.json'))['customers']
ia={c['id'] for c in a}; ib={c['id'] for c in b}
print("  default n=%d  include_deleted n=%d" % (len(a),len(b)))
print("  only in include_deleted:", sorted(ib-ia))
for c in b:
    if c['id'] in ib-ia: print("    deleted row:", json.dumps({k:c[k] for k in ('id','legal_name','deleted_at','last_invoice_id')}))
PY
echo; echo "##### single GET on the deleted customer:"
for id in $(python3 -c "
import json
a=json.load(open('$D/cust_default.json'))['customers']; b=json.load(open('$D/cust_incl.json'))['customers']
ia={c['id'] for c in a}
print(' '.join(c['id'] for c in b if c['id'] not in ia))"); do
  c=$(curl -sS -o /tmp/d.json -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B/invoicing/customers/$id")
  echo "  GET /invoicing/customers/$id -> $c"; head -c 400 /tmp/d.json; echo
done
echo; echo "##### full response header set on a single GET:"
curl -sS -o /dev/null -D - -H "Authorization: Bearer sandbox" "$B/accounts/30000000-0000-4000-8000-000000000002"
