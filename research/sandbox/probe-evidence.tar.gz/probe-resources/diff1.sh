#!/bin/bash
# $1=listfile $2=array key $3=id value $4=getfile $5=label $6=idfield
LF="$1"; AK="$2"; ID="$3"; GF="$4"; LBL="$5"; IDF="${6:-id}"
echo "########## $LBL   id=$ID"
jq --arg id "$ID" --arg k "$IDF" ".$AK[]|select(.[\$k]==\$id)" "$LF" > /tmp/L.json
cp "$GF" /tmp/G.json
echo "--- list-form bytes: $(wc -c </tmp/L.json | tr -d ' ')   get-form bytes: $(wc -c </tmp/G.json|tr -d ' ')"
jq -r '[paths(scalars)|map(tostring)|join(".")]|sort|unique|.[]' /tmp/L.json > /tmp/Lp.txt
jq -r '[paths(scalars)|map(tostring)|join(".")]|sort|unique|.[]' /tmp/G.json > /tmp/Gp.txt
echo "--- ONLY IN LIST:"; comm -23 /tmp/Lp.txt /tmp/Gp.txt | sed 's/^/    /'
echo "--- ONLY IN GET:";  comm -13 /tmp/Lp.txt /tmp/Gp.txt | sed 's/^/    /'
echo "--- VALUE DIFFS on shared paths:"
for p in $(comm -12 /tmp/Lp.txt /tmp/Gp.txt); do
  a=$(jq -c "getpath(\"$p\"|split(\".\")|map(if test(\"^[0-9]+$\") then tonumber else . end))" /tmp/L.json)
  b=$(jq -c "getpath(\"$p\"|split(\".\")|map(if test(\"^[0-9]+$\") then tonumber else . end))" /tmp/G.json)
  [ "$a" != "$b" ] && echo "    $p : LIST=$a  GET=$b"
done
echo "--- SEMANTIC EQUAL (sorted deep): $(jq -S -c . /tmp/L.json > /tmp/Ls; jq -S -c . /tmp/G.json > /tmp/Gs; cmp -s /tmp/Ls /tmp/Gs && echo YES || echo NO)"
echo
