#!/bin/bash
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
t(){ lbl="$1"; path="$2"
  code=$(curl -sS -o "$D/err_$lbl.body" -D "$D/err_$lbl.headers" -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B$path")
  ct=$(grep -i '^content-type' "$D/err_$lbl.headers" | tr -d '\r' | sed 's/content-type: //I')
  printf "%-26s %-3s %-26s %s\n" "$lbl" "$code" "$ct" "$(cat "$D/err_$lbl.body")"; }
echo "##### MISMATCHED PAIRING (real file id, wrong parent)"
t mm_txn_wrongparent  "/transactions/019f031b-cb48-7000-8000-000000000007/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15"
t mm_txn_swapped      "/transactions/019f0554-0bf0-7000-8000-00000000000a/files/8d073098-e509-4fe3-940b-ab22de36fe7a"
t mm_txn_noattachtxn  "/transactions/019f0554-0bf0-7000-8000-000000000001/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15"
t mm_inv_wrongparent  "/invoicing/invoices/70000000-0000-4000-8000-000000000002/files/50000000-0000-4000-8000-000000000027"
echo; echo "##### VALID FORMAT, UNKNOWN ID"
t unk_account     "/accounts/30000000-0000-4000-8000-999999999999"
t unk_account_zero "/accounts/00000000-0000-4000-8000-000000000000"
t unk_card        "/cards/20000000-0000-4000-8000-999999999999"
t unk_txn         "/transactions/019f0554-0bf0-7000-8000-999999999999"
t unk_statement   "/statements/999999"
t unk_customer    "/invoicing/customers/60000000-0000-4000-8000-999999999999"
t unk_invoice     "/invoicing/invoices/70000000-0000-4000-8000-999999999999"
t unk_txnfile     "/transactions/019f0554-0bf0-7000-8000-00000000000a/files/00000000-0000-4000-8000-000000000000"
t unk_invfile     "/invoicing/invoices/70000000-0000-4000-8000-000000000010/files/00000000-0000-4000-8000-000000000000"
