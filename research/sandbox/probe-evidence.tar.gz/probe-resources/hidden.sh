#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
echo "##### invoice ids present in list:"
python3 -c "
import json;d=json.load(open('$D/sw_invoices_list.json'))
print('  ', sorted(x['id'][-4:] for x in d['invoices']))"
echo "##### probing invoice id space 70000000-0000-4000-8000-0000000000NN"
for n in 00 01 02 03 04 05 06 07 08 09 0a 0b 0c 10 11 12 13 14 20; do
  id="70000000-0000-4000-8000-0000000000$n"
  c=$(curl -sS -o /tmp/h.json -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B/invoicing/invoices/$id")
  inlist=$(python3 -c "
import json;d=json.load(open('$D/sw_invoices_list.json'))
print('IN-LIST' if '$id' in [x['id'] for x in d['invoices']] else 'not-in-list')")
  num=$(python3 -c "
import json
try: print(json.load(open('/tmp/h.json')).get('invoice_number',''))
except: print('')")
  printf "  %s  %-3s %-11s %s\n" "$id" "$c" "$inlist" "$num"
done
