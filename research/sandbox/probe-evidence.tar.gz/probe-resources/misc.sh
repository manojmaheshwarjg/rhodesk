#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
t(){ printf "%-28s %-3s %s\n" "$1" "$2" "$(head -c 130 /tmp/m.json)"; }
r(){ c=$(curl -sS -g -o /tmp/m.json -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B$2" "${@:3}"); t "$1" "$c"; }
echo "##### CROSS-DOMAIN FILE IDS"
r inv_id_under_txn   "/transactions/019f0554-0bf0-7000-8000-00000000000a/files/50000000-0000-4000-8000-000000000027"
r txn_id_under_inv   "/invoicing/invoices/70000000-0000-4000-8000-000000000010/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15"
r customer_as_invoice "/invoicing/invoices/60000000-0000-4000-8000-000000000007"
r invoice_as_customer "/invoicing/customers/70000000-0000-4000-8000-000000000010"
r account_as_card     "/cards/30000000-0000-4000-8000-000000000002"
r card_as_account     "/accounts/20000000-0000-4000-8000-000000000001"
r txn_as_account      "/accounts/019f0554-0bf0-7000-8000-00000000000a"
echo; echo "##### CASE SENSITIVITY OF PATHS"
r upper_path      "/ACCOUNTS/30000000-0000-4000-8000-000000000002"
r mixed_path      "/Accounts/30000000-0000-4000-8000-000000000002"
r upper_files     "/transactions/019f0554-0bf0-7000-8000-00000000000a/FILES/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15"
echo; echo "##### CONTENT NEGOTIATION"
r accept_xml      "/accounts/30000000-0000-4000-8000-000000000002" -H "Accept: application/xml"
r accept_junk     "/accounts/30000000-0000-4000-8000-000000000002" -H "Accept: nonsense/x"
echo; echo "##### VERSION PREFIX VARIANTS (note: path built manually)"
for u in "https://rhoapi-sandbox.rho.co/api/v2/accounts" "https://rhoapi-sandbox.rho.co/api/accounts" "https://rhoapi-sandbox.rho.co/v1/accounts" "https://rhoapi-sandbox.rho.co/api/v1/accounts/30000000-0000-4000-8000-000000000002"; do
  c=$(curl -sS -o /tmp/m.json -w "%{http_code}" -H "Authorization: Bearer sandbox" "$u"); printf "  %-64s %-3s %s\n" "$u" "$c" "$(head -c 70 /tmp/m.json)"
done
