#!/bin/bash
D="$(dirname "$0")"; . "$D/lib.sh"
# ---- single GETs with real IDs harvested from lists
g get_account_checking  "/accounts/30000000-0000-4000-8000-000000000002"
g get_account_credit    "/accounts/30000000-0000-4000-8000-000000000009"
g get_card_1            "/cards/20000000-0000-4000-8000-000000000001"
g get_txn_attach        "/transactions/019f0554-0bf0-7000-8000-00000000000a"
g get_txn_multiattach   "/transactions/019f0143-3ea0-7000-8000-000000000003"
g get_statement_572981  "/statements/572981"
g get_customer_1        "/invoicing/customers/60000000-0000-4000-8000-000000000007"
g get_invoice_1         "/invoicing/invoices/70000000-0000-4000-8000-000000000010"
