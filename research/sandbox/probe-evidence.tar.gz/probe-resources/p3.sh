#!/bin/bash
D="$(dirname "$0")"; . "$D/lib.sh"
# ---- file endpoints, valid pairings
g file_txn_ok      "/transactions/019f0554-0bf0-7000-8000-00000000000a/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15"
g file_txn_multi_a "/transactions/019f0143-3ea0-7000-8000-000000000003/files/7de7495f-e0d3-4ada-a79d-6074e745dc33"
g file_txn_multi_b "/transactions/019f0143-3ea0-7000-8000-000000000003/files/602581d9-13e9-4aaa-a227-55645354bdf8"
g file_inv_ok      "/invoicing/invoices/70000000-0000-4000-8000-000000000010/files/50000000-0000-4000-8000-000000000027"
g file_inv_ok2     "/invoicing/invoices/70000000-0000-4000-8000-000000000001/files/50000000-0000-4000-8000-000000000020"
