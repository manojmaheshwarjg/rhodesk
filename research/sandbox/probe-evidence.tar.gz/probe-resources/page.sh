#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
tok=""; i=0; : > "$D/all_txns.ndjson"
while :; do
  i=$((i+1))
  if [ -z "$tok" ]; then url="$B/transactions?limit=100"; else url="$B/transactions?limit=100&page_token=$tok"; fi
  curl -sS -H "Authorization: Bearer sandbox" "$url" > "$D/pg_$i.json"
  n=$(python3 -c "import json;d=json.load(open('$D/pg_$i.json'));print(len(d.get('transactions',[])))")
  tok=$(python3 -c "import json;d=json.load(open('$D/pg_$i.json'));print(d.get('page',{}).get('next_page_token') or '')")
  python3 -c "
import json
d=json.load(open('$D/pg_$i.json'))
for t in d.get('transactions',[]): print(json.dumps(t))
" >> "$D/all_txns.ndjson"
  echo "page $i: $n rows, next=${tok:0:24}"
  [ -z "$tok" ] && break
  [ "$i" -ge 25 ] && { echo "stop: 25 pages"; break; }
done
echo "total: $(wc -l < "$D/all_txns.ndjson") transactions"
