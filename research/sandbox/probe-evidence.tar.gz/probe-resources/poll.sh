#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
for i in $(seq 1 90); do
  now=$(date -u +%H:%M:%S)
  s=$(curl -sS -H "Authorization: Bearer sandbox" "$B/statements/572981" | python3 -c "
import sys,json,urllib.parse as u
q=dict(u.parse_qsl(u.urlparse(json.load(sys.stdin)['pdf_url']).query));print(q['X-Goog-Date'],q['X-Goog-Signature'][:10])" 2>/dev/null)
  t=$(curl -sS -H "Authorization: Bearer sandbox" "$B/transactions/019f0554-0bf0-7000-8000-00000000000a/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15" | python3 -c "
import sys,json,urllib.parse as u
q=dict(u.parse_qsl(u.urlparse(json.load(sys.stdin)['download_url']).query));print(q['X-Goog-Date'],q['X-Goog-Signature'][:10])" 2>/dev/null)
  echo "$now  stmt=[$s]  txnfile=[$t]"
  sleep 20
done
