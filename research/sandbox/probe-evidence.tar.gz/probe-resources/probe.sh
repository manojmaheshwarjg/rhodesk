#!/bin/bash
B="https://rhoapi-sandbox.rho.co/api/v1"
D="$(dirname "$0")"
g() {
  name="$1"; path="$2"
  code=$(/usr/bin/curl -sS -D "$D/$name.headers" -o "$D/$name.body" -w "%{http_code}" \
    -H "Authorization: Bearer sandbox" "$B$path")
  printf "%-34s %-58s %s  %sB\n" "$name" "$path" "$code" "$(wc -c < "$D/$name.body" | tr -d ' ')"
}
g list_accounts   "/accounts"
g list_cards      "/cards"
g list_transactions "/transactions"
g list_statements "/statements"
g list_customers  "/invoicing/customers"
g list_invoices   "/invoicing/invoices"
