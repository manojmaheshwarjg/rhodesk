#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
U=$(curl -sS -H "Authorization: Bearer sandbox" "$B/transactions/019f0554-0bf0-7000-8000-00000000000a/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15" | python3 -c 'import sys,json;print(json.load(sys.stdin)["download_url"])')
echo "$U" > "$D/signed_url_sample.txt"
echo "##### 1. baseline fetch"; curl -sS -o /dev/null -w "  http=%{http_code} type=%{content_type} bytes=%{size_download}\n" "$U"
echo "##### 2. tampered signature (last char changed)"
BAD=$(python3 -c "
u='''$U'''
import re
s=re.search(r'X-Goog-Signature=([0-9a-f]+)',u).group(1)
b=s[:-1]+('0' if s[-1]!='0' else '1')
print(u.replace(s,b))")
curl -sS -o "$D/sig_bad.body" -w "  http=%{http_code} bytes=%{size_download}\n" "$BAD"; head -c 400 "$D/sig_bad.body"; echo
echo "##### 3. X-Goog-Expires forced to 1 (signature no longer matches)"
EXP1=$(python3 -c "u='''$U'''; print(u.replace('X-Goog-Expires=899','X-Goog-Expires=1'))")
curl -sS -o "$D/sig_exp1.body" -w "  http=%{http_code}\n" "$EXP1"; head -c 300 "$D/sig_exp1.body"; echo
echo "##### 4. no query string at all (bare object path)"
BARE=$(python3 -c "u='''$U'''; print(u.split('?')[0])")
curl -sS -o "$D/sig_bare.body" -w "  http=%{http_code}\n" "$BARE"; head -c 400 "$D/sig_bare.body"; echo
echo "##### 5. Range request on a valid signed URL"
curl -sS -r 0-9 -o "$D/sig_range.bin" -w "  http=%{http_code} bytes=%{size_download}\n" "$U"; echo "  content: [$(cat "$D/sig_range.bin")]"
echo "##### 6. HEAD on signed URL"
curl -sS -I -o "$D/sig_head.headers" -w "  http=%{http_code}\n" "$U"
echo "##### 7. repeat fetch 3x (is the URL single-use?)"
for i in 1 2 3; do curl -sS -o /dev/null -w "  fetch$i http=%{http_code} bytes=%{size_download}\n" "$U"; done
