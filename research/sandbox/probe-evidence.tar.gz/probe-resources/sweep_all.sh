#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
sweep(){ listpath="$1"; key="$2"; single="$3"; tag="$4"
  curl -sS -H "Authorization: Bearer sandbox" "$B$listpath" > "$D/sw_${tag}_list.json"
  : > "$D/sw_${tag}_get.ndjson"
  for id in $(python3 -c "
import json;d=json.load(open('$D/sw_${tag}_list.json'))
print(' '.join(str(x['id']) for x in d['$key']))"); do
    curl -sS -H "Authorization: Bearer sandbox" "$B$single/$id" >> "$D/sw_${tag}_get.ndjson"; echo >> "$D/sw_${tag}_get.ndjson"
  done
  echo "$tag: list=$(python3 -c "import json;print(len(json.load(open('$D/sw_${tag}_list.json'))['$key']))") got=$(grep -c . "$D/sw_${tag}_get.ndjson")"
}
sweep "/accounts" accounts "/accounts" accounts
sweep "/cards" cards "/cards" cards
sweep "/invoicing/customers" customers "/invoicing/customers" customers
sweep "/invoicing/invoices" invoices "/invoicing/invoices" invoices
sweep "/statements" statements "/statements" statements
