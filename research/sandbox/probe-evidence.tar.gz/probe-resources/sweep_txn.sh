#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
: > "$D/sweep_txn_get.ndjson"
while read -r id; do
  curl -sS -H "Authorization: Bearer sandbox" "$B/transactions/$id" >> "$D/sweep_txn_get.ndjson"
  echo >> "$D/sweep_txn_get.ndjson"
done < <(python3 -c "
import json
for l in open('$D/all_txns.ndjson'): print(json.loads(l)['id'])")
echo "fetched: $(wc -l < "$D/sweep_txn_get.ndjson")"
