#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
w(){ m="$1"; path="$2"; extra="$3"
  lbl="$m$(echo "$path" | tr '/{}?=&' '_')"
  code=$(curl -sS -X "$m" $extra -o "$D/w_$lbl.body" -D "$D/w_$lbl.headers" -w "%{http_code}" \
    -H "Authorization: Bearer sandbox" -H "Content-Type: application/json" \
    --data '{"note":"probe"}' "$B$path")
  allow=$(grep -i '^allow' "$D/w_$lbl.headers" | tr -d '\r')
  printf "%-7s %-48s %-3s %-22s %s\n" "$m" "$path" "$code" "$allow" "$(head -c 120 "$D/w_$lbl.body")"; }
echo "##### WRITE METHODS on collection + single-resource paths"
for m in POST PUT PATCH DELETE; do
  w "$m" "/accounts"
  w "$m" "/accounts/30000000-0000-4000-8000-000000000002"
  w "$m" "/transactions/019f0554-0bf0-7000-8000-00000000000a"
  w "$m" "/invoicing/invoices/70000000-0000-4000-8000-000000000010"
  echo
done
