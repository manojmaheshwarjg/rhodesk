#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
echo "##### 405 body is empty? (POST /accounts)"
curl -sS -X POST -D "$D/w405.headers" -o "$D/w405.body" -H "Authorization: Bearer sandbox" -H "Content-Type: application/json" --data '{"a":1}' "$B/accounts"
echo "body bytes: $(wc -c < "$D/w405.body")  content: [$(cat "$D/w405.body")]"; echo "--- headers:"; cat "$D/w405.headers"
echo; echo "##### HEAD / OPTIONS / TRACE"
for m in HEAD OPTIONS TRACE; do
  code=$(curl -sS -X "$m" -o "$D/m_$m.body" -D "$D/m_$m.headers" -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B/accounts")
  printf "%-8s %s  allow=[%s]  bodybytes=%s\n" "$m" "$code" "$(grep -i '^allow' "$D/m_$m.headers"|tr -d '\r'|sed 's/allow: //I')" "$(wc -c < "$D/m_$m.body"|tr -d ' ')"
done
echo; echo "##### WRITE on FILE endpoints + unknown resource + BAD TOKEN ordering"
p(){ printf "%-7s %-58s %-14s %-3s %s\n" "$1" "$2" "$3" "$4" "$5"; }
for m in POST DELETE; do
  c=$(curl -sS -X "$m" -o /tmp/x -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B/transactions/019f0554-0bf0-7000-8000-00000000000a/files/2c436c0c-5d8b-4114-aa2d-8d7bd64d9b15")
  p "$m" "/transactions/{id}/files/{fid}" "goodtoken" "$c" "[$(cat /tmp/x)]"
  c=$(curl -sS -X "$m" -o /tmp/x -w "%{http_code}" -H "Authorization: Bearer WRONGTOKEN" "$B/accounts")
  p "$m" "/accounts" "BADTOKEN" "$c" "[$(head -c 120 /tmp/x)]"
  c=$(curl -sS -X "$m" -o /tmp/x -w "%{http_code}" "$B/accounts")
  p "$m" "/accounts" "NOTOKEN" "$c" "[$(head -c 120 /tmp/x)]"
  c=$(curl -sS -X "$m" -o /tmp/x -w "%{http_code}" -H "Authorization: Bearer sandbox" "$B/accounts/30000000-0000-4000-8000-999999999999")
  p "$m" "/accounts/{unknown-id}" "goodtoken" "$c" "[$(head -c 120 /tmp/x)]"
done
