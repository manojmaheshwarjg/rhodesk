#!/bin/bash
export PATH=/usr/bin:/bin
B="https://rhoapi-sandbox.rho.co/api/v1"; D="$(dirname "$0")"
echo "##### METHOD-vs-AUTH ORDERING (POST with a real body)"
r(){ printf "%-7s %-34s %-12s %-3s allow=[%s] body=[%s]\n" "$1" "$2" "$3" "$4" "$5" "$6"; }
for tok in "Bearer sandbox" "Bearer WRONGTOKEN" "NONE"; do
  for m in POST PUT PATCH DELETE; do
    if [ "$tok" = "NONE" ]; then
      c=$(curl -sS -X "$m" -H "Content-Type: application/json" --data '{"x":1}' -o /tmp/x -D /tmp/hh -w "%{http_code}" "$B/accounts")
    else
      c=$(curl -sS -X "$m" -H "Authorization: $tok" -H "Content-Type: application/json" --data '{"x":1}' -o /tmp/x -D /tmp/hh -w "%{http_code}" "$B/accounts")
    fi
    r "$m" "/accounts" "$tok" "$c" "$(grep -i '^allow' /tmp/hh|tr -d '\r'|sed 's/allow: //I')" "$(head -c 90 /tmp/x)"
  done
done
echo; echo "##### GET with bad/no token for comparison"
c=$(curl -sS -H "Authorization: Bearer WRONGTOKEN" -o /tmp/x -w "%{http_code}" "$B/accounts"); echo "GET badtoken $c [$(cat /tmp/x)]"
c=$(curl -sS -o /tmp/x -w "%{http_code}" "$B/accounts"); echo "GET notoken  $c [$(cat /tmp/x)]"
echo; echo "##### TRACE body:"; curl -sS -X TRACE -H "Authorization: Bearer sandbox" "$B/accounts" | head -c 300
echo; echo; echo "##### POST to a NONEXISTENT route (does 404 beat 405?)"
c=$(curl -sS -X POST -H "Authorization: Bearer sandbox" -H "Content-Type: application/json" --data '{}' -o /tmp/x -w "%{http_code}" "$B/nope"); echo "POST /nope -> $c [$(cat /tmp/x)]"
c=$(curl -sS -X POST -H "Authorization: Bearer sandbox" -H "Content-Type: application/json" --data '{}' -o /tmp/x -D /tmp/hh -w "%{http_code}" "$B/invoicing/customers"); echo "POST /invoicing/customers -> $c allow=[$(grep -i '^allow' /tmp/hh|tr -d '\r'|sed 's/allow: //I')]"
